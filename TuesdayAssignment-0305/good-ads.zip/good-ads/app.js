
// call the getRandomAd function

// get the adImage by id

// set the src property to the new random ad image  
